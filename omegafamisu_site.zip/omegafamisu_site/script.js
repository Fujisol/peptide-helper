/*
  Omegafamisu Peptide Helper by Kushhzi – interactive behaviour

  This script powers the web app.  It handles:
  • User login and session management via localStorage
  • Dynamic construction of the progress dashboard table
  • Chart rendering with Chart.js for weight and dosage tracking per user
  • Computation of rolling 28‑day totals, delta weight and progress percentages
  • A peptide calculator for syringe dosing similar to the Particle Peptides calculator
  • Basic navigation between the dashboard and calculator

  The app uses an in‑memory data store to hold user schemas.  A new user will
  automatically inherit a blank schema with dates prefilled every six days
  starting at 16‑09‑2025.  Existing data is stored in localStorage so your
  progress persists between sessions on the same device.
*/

// In‑memory dataset keyed by user name.  If localStorage contains prior
// progress we will load from there.  Otherwise we seed with two defaults.
let data = {};
const startDateStr = '2025-09-16';
const scheduleIntervalDays = 6;
const weeksCount = 12;
// Base mg arrays for our initial users (first 8 weeks filled).  Remaining
// entries will be null for flexibility.
const defaultMgGreg = [0.5, 1.5, 2.0, 2.0, 2.5, 2.5, 2.5, 2.5];
const defaultMgBoro = [1.0, 1.0, 1.5, 2.0, 2.0, 2.5, 2.5, 2.5];

function generateSchema(mgSchedule = []) {
  const entries = [];
  const start = new Date(startDateStr);
  for (let i = 0; i < weeksCount; i++) {
    const date = new Date(start.getTime() + i * scheduleIntervalDays * 24 * 60 * 60 * 1000);
    const mg = i < mgSchedule.length ? mgSchedule[i] : null;
    entries.push({
      date: date.toISOString().split('T')[0],
      doseMg: mg,
      weight: null,
      time: '',
      appetite: '',
      notes: ''
    });
  }
  return entries;
}

function loadData() {
  const stored = localStorage.getItem('omegafamisuData');
  if (stored) {
    try {
      data = JSON.parse(stored);
      return;
    } catch (e) {
      console.warn('Failed to parse stored data:', e);
    }
  }
  // Seed with Greg and Boro
  data['Greg'] = generateSchema(defaultMgGreg);
  data['Boro'] = generateSchema(defaultMgBoro);
}

function saveData() {
  localStorage.setItem('omegafamisuData', JSON.stringify(data));
}

// Current logged in user
let currentUser = null;
let weightChart = null;
let doseChart = null;

// DOM references
const loginSection = document.getElementById('login-section');
const dashboardSection = document.getElementById('dashboard-section');
const calculatorSection = document.getElementById('calculator-section');
const loginForm = document.getElementById('login-form');
const usernameInput = document.getElementById('username');
const userSelect = document.getElementById('user-select');
const addUserBtn = document.getElementById('add-user-btn');
const logoutBtn = document.getElementById('nav-logout');
const navDashboard = document.getElementById('nav-dashboard');
const navCalculator = document.getElementById('nav-calculator');
const dataTable = document.getElementById('data-table');

// Calculator DOM
const calcVialSelect = document.getElementById('calc-vial');
const calcVialOther = document.getElementById('calc-vial-other');
const calcWaterSelect = document.getElementById('calc-water');
const calcWaterOther = document.getElementById('calc-water-other');
const calcSyringe = document.getElementById('calc-syringe');
const calcDose = document.getElementById('calc-dose');
const calcBtn = document.getElementById('calc-btn');
const calcResult = document.getElementById('calculator-result');

// Initialise application
function init() {
  loadData();
  // Check if there is an existing logged in user
  const storedUser = localStorage.getItem('omegafamisuUser');
  if (storedUser && data[storedUser]) {
    currentUser = storedUser;
    showDashboard();
  } else {
    showLogin();
  }
  attachEventListeners();
}

function attachEventListeners() {
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = usernameInput.value.trim();
    if (!name) return;
    if (!data[name]) {
      // Create a new schema with blank mg schedule
      data[name] = generateSchema([]);
    }
    currentUser = name;
    localStorage.setItem('omegafamisuUser', currentUser);
    saveData();
    usernameInput.value = '';
    showDashboard();
  });
  addUserBtn.addEventListener('click', () => {
    const newName = prompt('Enter a name for the new user:');
    if (!newName) return;
    const trimmed = newName.trim();
    if (!trimmed) return;
    if (!data[trimmed]) {
      data[trimmed] = generateSchema([]);
      saveData();
    }
    refreshUserSelect(trimmed);
  });
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('omegafamisuUser');
    currentUser = null;
    showLogin();
  });
  navDashboard.addEventListener('click', () => {
    showDashboard();
  });
  navCalculator.addEventListener('click', () => {
    showCalculator();
  });
  // Calculator interactions
  calcVialSelect.addEventListener('change', () => {
    if (calcVialSelect.value === 'other') {
      calcVialOther.classList.remove('hidden');
    } else {
      calcVialOther.classList.add('hidden');
    }
  });
  calcWaterSelect.addEventListener('change', () => {
    if (calcWaterSelect.value === 'other') {
      calcWaterOther.classList.remove('hidden');
    } else {
      calcWaterOther.classList.add('hidden');
    }
  });
  calcBtn.addEventListener('click', (e) => {
    e.preventDefault();
    performCalculation();
  });
}

function showLogin() {
  loginSection.classList.remove('hidden');
  dashboardSection.classList.add('hidden');
  calculatorSection.classList.add('hidden');
  logoutBtn.classList.add('hidden');
  navDashboard.classList.add('hidden');
  navCalculator.classList.add('hidden');
}

function showDashboard() {
  if (!currentUser) return showLogin();
  loginSection.classList.add('hidden');
  dashboardSection.classList.remove('hidden');
  calculatorSection.classList.add('hidden');
  logoutBtn.classList.remove('hidden');
  navDashboard.classList.remove('hidden');
  navCalculator.classList.remove('hidden');
  refreshUserSelect(currentUser);
  renderTable();
  renderCharts();
}

function showCalculator() {
  if (!currentUser) return showLogin();
  dashboardSection.classList.add('hidden');
  loginSection.classList.add('hidden');
  calculatorSection.classList.remove('hidden');
  logoutBtn.classList.remove('hidden');
  navDashboard.classList.remove('hidden');
  navCalculator.classList.remove('hidden');
}

function refreshUserSelect(selected = null) {
  userSelect.innerHTML = '';
  Object.keys(data).forEach((name) => {
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    if (name === (selected || currentUser)) {
      opt.selected = true;
    }
    userSelect.appendChild(opt);
  });
  userSelect.onchange = () => {
    currentUser = userSelect.value;
    localStorage.setItem('omegafamisuUser', currentUser);
    renderTable();
    renderCharts();
  };
}

function computeMetrics(entries) {
  // Add computed fields: deltaWeight, progressPercent, mgRolling
  let prevWeight = null;
  const now = new Date();
  return entries.map((entry, idx) => {
    const newEntry = { ...entry };
    // delta weight
    if (entry.weight != null && entry.weight !== '') {
      const currentWeight = parseFloat(entry.weight);
      if (!isNaN(currentWeight) && prevWeight != null) {
        newEntry.deltaWeight = currentWeight - prevWeight;
      } else {
        newEntry.deltaWeight = null;
      }
      prevWeight = currentWeight;
    } else {
      newEntry.deltaWeight = null;
    }
    // progress percentage (dose relative to 10 mg max)
    if (entry.doseMg != null) {
      newEntry.progress = Math.min((entry.doseMg / 10) * 100, 100);
    } else {
      newEntry.progress = 0;
    }
    // rolling mg sum over last 28 days
    const entryDate = new Date(entry.date);
    let sum = 0;
    entries.forEach((e) => {
      if (e.doseMg != null) {
        const d = new Date(e.date);
        const diffDays = (entryDate - d) / (1000 * 60 * 60 * 24);
        if (diffDays >= 0 && diffDays <= 28) {
          sum += e.doseMg;
        }
      }
    });
    newEntry.mgRolling = sum;
    return newEntry;
  });
}

function renderTable() {
  const entries = data[currentUser];
  const computed = computeMetrics(entries);
  // Build table header
  const header = `
    <thead>
      <tr>
        <th>Date</th>
        <th>Dose (mg)</th>
        <th>Weight (kg)</th>
        <th>Δ Weight</th>
        <th>Time</th>
        <th>Appetite (1‑5)</th>
        <th>Notes</th>
        <th>Progress %</th>
        <th>28‑day total (mg)</th>
      </tr>
    </thead>
  `;
  // Build table body
  let body = '<tbody>';
  computed.forEach((entry, idx) => {
    const doseDisplay = entry.doseMg != null ? entry.doseMg.toFixed(2) : '';
    let deltaDisplay = '';
    let deltaClass = '';
    if (entry.deltaWeight != null) {
      const delta = entry.deltaWeight;
      deltaDisplay = (delta > 0 ? '+' : '') + delta.toFixed(1);
      deltaClass = delta > 0 ? 'red-text' : 'green-text';
    }
    const weightVal = entry.weight != null ? entry.weight : '';
    const appetiteVal = entry.appetite || '';
    const notesVal = entry.notes || '';
    const progressPercent = entry.progress.toFixed(1);
    // Data bar width for mg (progress)
    const barStyle = `width: ${progressPercent}%`;
    const highlightClass = (entry.doseMg != null && (entry.weight == null || entry.weight === '')) ? 'highlight-empty' : '';
    body += `
      <tr class="${highlightClass}">
        <td>${entry.date}</td>
        <td>${doseDisplay}</td>
        <td class="editable" data-field="weight" data-index="${idx}">${weightVal}</td>
        <td class="${deltaClass}">${deltaDisplay}</td>
        <td class="editable" data-field="time" data-index="${idx}">${entry.time}</td>
        <td class="editable" data-field="appetite" data-index="${idx}">${appetiteVal}</td>
        <td class="editable" data-field="notes" data-index="${idx}">${notesVal}</td>
        <td>
          <div class="progress-container">
            <span>${progressPercent}%</span>
            <div class="progress-bar"><span class="progress-fill" style="width:${progressPercent}%"></span></div>
          </div>
        </td>
        <td>${entry.mgRolling.toFixed(2)}</td>
      </tr>
    `;
  });
  body += '</tbody>';
  dataTable.innerHTML = header + body;
  // Add click handlers for editable cells
  dataTable.querySelectorAll('.editable').forEach((cell) => {
    cell.addEventListener('click', handleEditCell);
  });
}

function handleEditCell(e) {
  const cell = e.currentTarget;
  const field = cell.getAttribute('data-field');
  const index = parseInt(cell.getAttribute('data-index'), 10);
  const oldVal = cell.textContent;
  const input = document.createElement('input');
  input.type = 'text';
  input.value = oldVal;
  input.style.width = '100%';
  cell.innerHTML = '';
  cell.appendChild(input);
  input.focus();
  input.addEventListener('blur', () => {
    const newVal = input.value.trim();
    // Save value into dataset
    if (field === 'weight') {
      data[currentUser][index].weight = newVal || null;
    } else if (field === 'time') {
      data[currentUser][index].time = newVal;
    } else if (field === 'appetite') {
      data[currentUser][index].appetite = newVal;
    } else if (field === 'notes') {
      data[currentUser][index].notes = newVal;
    }
    saveData();
    renderTable();
    renderCharts();
  });
  input.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') {
      ev.preventDefault();
      input.blur();
    }
  });
}

function renderCharts() {
  const entries = data[currentUser];
  const labels = entries.map((e) => e.date);
  // Weight chart
  const weights = entries.map((e) => {
    const w = parseFloat(e.weight);
    return isNaN(w) ? null : w;
  });
  const doses = entries.map((e) => e.doseMg != null ? e.doseMg : null);
  // Destroy previous charts if any
  if (weightChart) weightChart.destroy();
  if (doseChart) doseChart.destroy();
  const ctxW = document.getElementById('weight-chart').getContext('2d');
  weightChart = new Chart(ctxW, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: `${currentUser} Weight (kg)`,
          data: weights,
          spanGaps: true,
          borderWidth: 2,
          borderColor: getUserColour(currentUser),
          backgroundColor: 'rgba(0,0,0,0)'
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          ticks: {
            color: '#a4adc3'
          },
          grid: {
            color: '#1e293b'
          }
        },
        x: {
          ticks: {
            color: '#a4adc3'
          },
          grid: {
            color: '#1e293b'
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#e0e6f0'
          }
        }
      }
    }
  });
  // Dose chart
  const ctxD = document.getElementById('dose-chart').getContext('2d');
  doseChart = new Chart(ctxD, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: `${currentUser} Dose (mg)`,
          data: doses,
          borderWidth: 1,
          backgroundColor: getUserColour(currentUser)
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          ticks: {
            color: '#a4adc3'
          },
          grid: {
            color: '#1e293b'
          }
        },
        x: {
          ticks: {
            color: '#a4adc3'
          },
          grid: {
            color: '#1e293b'
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#e0e6f0'
          }
        }
      }
    }
  });
}

function getUserColour(name) {
  if (name === 'Greg') return 'rgba(180, 0, 255, 0.7)';
  if (name === 'Boro') return 'rgba(0, 145, 255, 0.7)';
  // Other users pick highlight colour
  return 'rgba(0, 255, 234, 0.7)';
}

function performCalculation() {
  // Get vial mg
  let vialMg;
  if (calcVialSelect.value === 'other') {
    vialMg = parseFloat(calcVialOther.value);
  } else {
    vialMg = parseFloat(calcVialSelect.value);
  }
  // Get water ml
  let waterMl;
  if (calcWaterSelect.value === 'other') {
    waterMl = parseFloat(calcWaterOther.value);
  } else {
    waterMl = parseFloat(calcWaterSelect.value);
  }
  const doseMcg = parseFloat(calcDose.value);
  if (isNaN(vialMg) || isNaN(waterMl) || isNaN(doseMcg) || vialMg <= 0 || waterMl <= 0 || doseMcg <= 0) {
    calcResult.innerHTML = '<p style="color:var(--danger-colour)">Please fill in valid values.</p>';
    return;
  }
  // Compute ml per mg
  const mlPerMg = waterMl / vialMg;
  // Convert mcg to mg
  const doseMg = doseMcg / 1000;
  const doseMl = doseMg * mlPerMg;
  // Units: 1 ml = 100 units across all insulin syringes
  const units = doseMl * 100;
  const syringeVolume = parseFloat(calcSyringe.value);
  // Determine if selected syringe can accommodate dose
  const maxUnits = syringeVolume * 100;
  let advice = '';
  if (units > maxUnits) {
    advice = `<p style="color:var(--danger-colour)">Warning: the desired dose requires ${units.toFixed(1)} IU which exceeds the capacity of a ${syringeVolume} ml syringe (${maxUnits} IU). Please choose a larger syringe or split the dose.</p>`;
  }
  calcResult.innerHTML = `
    <p>To deliver <strong>${doseMcg.toFixed(1)} mcg</strong> from a vial containing <strong>${vialMg} mg</strong> reconstituted with <strong>${waterMl} ml</strong>, draw <strong>${doseMl.toFixed(3)} ml</strong> (${units.toFixed(1)} IU) on your ${syringeVolume} ml syringe.</p>
    ${advice}
  `;
}

// Kick off the app when the DOM is ready
document.addEventListener('DOMContentLoaded', init);